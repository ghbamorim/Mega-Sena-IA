import json
import boto3
import os
import requests

S3_BUCKET = os.environ.get("S3_BUCKET", "meu-bucket")
s3 = boto3.client("s3", endpoint_url="http://s3.localhost.localstack.cloud:4566")

def lambda_handler(event, context):
    dataset = []

    # Carregar dataset existente do S3
    try:
        response = s3.get_object(Bucket=S3_BUCKET, Key="dataset.json")
        dataset = json.loads(response["Body"].read())
    except s3.exceptions.NoSuchKey:
        dataset = []
    except Exception as e:
        print(f"Erro ao carregar dataset: {e}")
        dataset = []

    # Consultar API da Caixa com timeout
    url = "https://servicebus2.caixa.gov.br/portaldeloterias/api/megasena/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://loterias.caixa.gov.br/",
        "Origin": "https://loterias.caixa.gov.br",
    }

    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            novo_registro = response.json()
            # Verifica se já existe no dataset
            if not any(item.get("numero") == novo_registro.get("numero") for item in dataset):
                dataset.append(novo_registro)
                # Salvar dataset atualizado no S3
                s3.put_object(
                    Bucket=S3_BUCKET,
                    Key="dataset.json",
                    Body=json.dumps(dataset, ensure_ascii=False, indent=2),
                    ContentType="application/json"
                )
    except Exception as e:
        print(f"Erro ao consultar API: {e}")

    return {"dataset": dataset, "total_registros": len(dataset)}
